import time

countdown_time = int(input("Enter a time in seconds to count down from:"))

for x in range(countdown_time, 0 , -1):
    seconds = (x % 60)
    minutes = int((x / 60) % 60)
    hours = int((x / 3600))
    print(f"{hours:02}:{minutes:02}:{seconds:02}")
    time.sleep(1)

print("time is up")